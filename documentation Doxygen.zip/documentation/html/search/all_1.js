var searchData=
[
  ['2_0',['2',['../system__stm32g4xx_8c.html#autotoc_md12',1,'PLL_Q                                  | 2'],['../system__stm32g4xx_8c.html#autotoc_md13',1,'PLL_R                                  | 2']]]
];
