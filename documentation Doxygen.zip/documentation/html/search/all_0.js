var searchData=
[
  ['1_0',['1',['../system__stm32g4xx_8c.html#autotoc_md6',1,'AHB Prescaler                          | 1'],['../system__stm32g4xx_8c.html#autotoc_md7',1,'APB1 Prescaler                         | 1'],['../system__stm32g4xx_8c.html#autotoc_md8',1,'APB2 Prescaler                         | 1'],['../system__stm32g4xx_8c.html#autotoc_md9',1,'PLL_M                                  | 1']]],
  ['16_1',['PLL_N                                  | 16',['../system__stm32g4xx_8c.html#autotoc_md10',1,'']]],
  ['16000000_2',['16000000',['../system__stm32g4xx_8c.html#autotoc_md5',1,'HCLK(Hz)                               | 16000000'],['../system__stm32g4xx_8c.html#autotoc_md4',1,'SYSCLK(Hz)                             | 16000000']]]
];
