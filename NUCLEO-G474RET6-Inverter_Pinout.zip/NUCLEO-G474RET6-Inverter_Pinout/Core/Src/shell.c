/*
 * shell.c
 *
 *  Created on: Oct 10, 2024
 *      Author: Selim Farci & Loic Menoret
 */

#include "usart.h"
#include "adc.h"
#include "shell.h"
#include "tim.h"
#include <stdio.h>
#include <string.h>

uint8_t prompt[] = "user@Nucleo-STM32G431>>";
uint8_t started[] =
		"\r\n*-----------------------------*"
		"\r\n| Welcome on Nucleo-STM32G431 |"
		"\r\n*-----------------------------*"
		"\r\n";
uint8_t newline[] = "\r\n";
uint8_t cmdNotFound[] = "Command not found\r\n";
uint32_t uartRxReceived;
uint8_t uartRxBuffer[UART_RX_BUFFER_SIZE];
uint8_t uartTxBuffer[UART_TX_BUFFER_SIZE];

#define PulseInit 2125

// Paramètre capteur de courant (depuis la datahseet)
#define Voffset 2.5 // 2.5V
#define Sn 50E-3  // 50 mV/A = 0.05 V/A
// Paramètre ADC
#define ADC_Bits 12 // Nombre de bit de l'adc
#define ADC_Vref 3.3 // 3.3V
#define ADC_DMA_Buffer_Size 128
uint32_t adcBuffer_Brut[ADC_DMA_Buffer_Size];
uint32_t adcBuffer_reel[ADC_DMA_Buffer_Size];

char cmdBuffer[CMD_BUFFER_SIZE];
int idx_cmd;
char *argv[MAX_ARGS];
int argc = 0;
char *token;
int newCmdReady = 0;
int Actual_pulseChannel1 = PulseInit;
int Actual_pulseChannel2 = PulseInit;
int period_value = 4250;

/**
 * Prototypes des fonctions
 */
void executeHelp();
void executePinout();
void executeStart();
void executeStop();
void executeSpeed();
void executeCurrentValue();

/**
 * @brief Initialisation du shell UART.
 *
 * @param none
 * @retval none
 */
void Shell_Init(void) {
	memset(argv, NULL, MAX_ARGS * sizeof(char *));
	memset(cmdBuffer, NULL, CMD_BUFFER_SIZE * sizeof(char));
	memset(uartRxBuffer, NULL, UART_RX_BUFFER_SIZE * sizeof(char));
	memset(uartTxBuffer, NULL, UART_TX_BUFFER_SIZE * sizeof(char));

	HAL_UART_Receive_IT(&huart2, uartRxBuffer, UART_RX_BUFFER_SIZE);
	HAL_Delay(10);
	HAL_UART_Transmit(&huart2, started, sizeof(started), HAL_MAX_DELAY);
	HAL_UART_Transmit(&huart2, prompt, sizeof(prompt), HAL_MAX_DELAY);
}

/**
 * @brief Boucle principale du shell UART.
 *
 * @param none
 * @retval none
 */
void Shell_loop(void) {
	if (uartRxReceived) {
		switch (uartRxBuffer[0]) {
		case ASCII_CR:
			HAL_UART_Transmit(&huart2, newline, sizeof(newline), HAL_MAX_DELAY);
			cmdBuffer[idx_cmd] = '\0';
			argc = 0;
			token = strtok(cmdBuffer, " ");
			while (token != NULL) {
				argv[argc++] = token;
				token = strtok(NULL, " ");
			}
			idx_cmd = 0;
			newCmdReady = 1;
			break;

		case ASCII_DEL:
			cmdBuffer[idx_cmd--] = '\0';
			HAL_UART_Transmit(&huart2, uartRxBuffer, UART_RX_BUFFER_SIZE, HAL_MAX_DELAY);
			break;

		default:
			cmdBuffer[idx_cmd++] = uartRxBuffer[0];
			HAL_UART_Transmit(&huart2, uartRxBuffer, UART_RX_BUFFER_SIZE, HAL_MAX_DELAY);
		}
		uartRxReceived = 0;
	}

	if (newCmdReady) {
		if (strcmp(argv[0], "help") == 0) {
			executeHelp();
		} else if (strcmp(argv[0], "pinout") == 0) {
			executePinout();
		} else if (strcmp(argv[0], "start") == 0) {
			executeStart();
		} else if (strcmp(argv[0], "stop") == 0) {
			executeStop();
		} else if (strcmp(argv[0], "speed") == 0) {
			executeSpeed();
		} else if (strcmp(argv[0], "currentvalue") == 0) {
			executeCurrentValue();
		} else if (strcmp(argv[0], "infospeed") == 0) {
			executeInfoSpeed();
		} else {
			HAL_UART_Transmit(&huart2, cmdNotFound, sizeof(cmdNotFound), HAL_MAX_DELAY);
		}

		HAL_UART_Transmit(&huart2, prompt, sizeof(prompt), HAL_MAX_DELAY);
		newCmdReady = 0;
	}
}


/**
 * @brief Callback de l'UART.
 *
 * @retval none
 */

void HAL_UART_RxCpltCallback (UART_HandleTypeDef * huart){
	uartRxReceived = 1;
	HAL_UART_Receive_IT(&huart2, uartRxBuffer, UART_RX_BUFFER_SIZE);
}


/**
 * @brief Explique le fonctionnement des différante fonction sur le shell.
 *
 * @param none
 * @retval none
 */

void executeHelp() {
	int uartTxStringLength;
	uartTxStringLength = snprintf((char *)uartTxBuffer, UART_TX_BUFFER_SIZE,
			"Start : Init PWMs and speed = 0 \r\n");
	HAL_UART_Transmit(&huart2, uartTxBuffer, uartTxStringLength, HAL_MAX_DELAY);

	uartTxStringLength = snprintf((char *)uartTxBuffer, UART_TX_BUFFER_SIZE,
			"Stop : Power Off => need Start to relaunch \r\n");
	HAL_UART_Transmit(&huart2, uartTxBuffer, uartTxStringLength, HAL_MAX_DELAY);

	uartTxStringLength = snprintf((char *)uartTxBuffer, UART_TX_BUFFER_SIZE,
			"Speed XXX : XXX need to be a pourcentage \r\n");
	HAL_UART_Transmit(&huart2, uartTxBuffer, uartTxStringLength, HAL_MAX_DELAY);

	uartTxStringLength = snprintf((char *)uartTxBuffer, UART_TX_BUFFER_SIZE,
			"currentvalue : Show the value of the current \r\n");
	HAL_UART_Transmit(&huart2, uartTxBuffer, uartTxStringLength, HAL_MAX_DELAY);
	uartTxStringLength = snprintf((char *)uartTxBuffer, UART_TX_BUFFER_SIZE,
				"infospeed : show the value and the direction of the speed \r\n");
		HAL_UART_Transmit(&huart2, uartTxBuffer, uartTxStringLength, HAL_MAX_DELAY);
}




void executePinout(void) {
	int uartTxStringLength = snprintf((char *)uartTxBuffer, UART_TX_BUFFER_SIZE, "Power ON\r\n");
	HAL_UART_Transmit(&huart2, uartTxBuffer, uartTxStringLength, HAL_MAX_DELAY);
}


/**
 * @brief Allume les PWM et initialise les rapport cyclique à 50%.
 *
 * @param none
 * @retval none
 */


void executeStart(void) {
	__HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_1, PulseInit);
	__HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_2, PulseInit);

	HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_1);
	HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_2);
	HAL_TIMEx_PWMN_Start(&htim1, TIM_CHANNEL_1);
	HAL_TIMEx_PWMN_Start(&htim1, TIM_CHANNEL_2);

	int uartTxStringLength = snprintf((char *)uartTxBuffer, UART_TX_BUFFER_SIZE, "POWER ON\r\n");
	HAL_UART_Transmit(&huart2, uartTxBuffer, uartTxStringLength, HAL_MAX_DELAY);
}


/**
 * @brief Arrete les PWM.
 *
 * @param none
 * @retval none
 */

void executeStop(void) {
	HAL_TIM_PWM_Stop(&htim1, TIM_CHANNEL_1);
	HAL_TIM_PWM_Stop(&htim1, TIM_CHANNEL_2);
	HAL_TIMEx_PWMN_Stop(&htim1, TIM_CHANNEL_1);
	HAL_TIMEx_PWMN_Stop(&htim1, TIM_CHANNEL_2);

	int uartTxStringLength = snprintf((char *)uartTxBuffer, UART_TX_BUFFER_SIZE, "Power OFF\r\n");
	HAL_UART_Transmit(&huart2, uartTxBuffer, uartTxStringLength, HAL_MAX_DELAY);
}


/**
 * @brief Modifie la valeur du raport cyclique de tous les PWM.
 *
 * @shellparam speed + "Pourcentage du rapport cyclique"
 *
 * @param none
 * @retval none
 */


void executeSpeed(void) {
	int speedValue;
	if(argc == 2 && sscanf(argv[1], "%d", &speedValue) == 1 && speedValue >= 0 && speedValue <= 100){
		int pulseChannel1 = (speedValue * period_value) / 100;  // pour le canal 1
		//int pulseChannel2 = period_value - pulseChannel1; // pour le canal 2
		int uartTxStringLength = snprintf((char *)uartTxBuffer, UART_TX_BUFFER_SIZE, "Speed set to %d%%\r\n", speedValue);
		HAL_UART_Transmit(&huart2, uartTxBuffer, uartTxStringLength, HAL_MAX_DELAY);

		//__HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_1, pulseChannel1);
		//__HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_2, pulseChannel2);

		// Rampe de vitesse
		int rampTime = 250; // Durée totale de la rampe en ms (par exemple 1 seconde)
		int steps = 50; // Nombre de petites étapes (période de la rampe)
		int delayStep = rampTime / steps; // Délai par étape (en ms)

		while(pulseChannel1 < Actual_pulseChannel1){
			Actual_pulseChannel2++;
			Actual_pulseChannel1--;
			__HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_1, Actual_pulseChannel1);
			__HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_2, Actual_pulseChannel2);
			HAL_Delay(delayStep);  // Attendre avant de mettre à jour la vitesse
		}
		while(pulseChannel1 > Actual_pulseChannel1){
			Actual_pulseChannel2--;
			Actual_pulseChannel1++;
			__HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_1, Actual_pulseChannel1);
			__HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_2, Actual_pulseChannel2);
			HAL_Delay(delayStep);  // Attendre avant de mettre à jour la vitesse
		}
	}
	else{
		int uartTxStringLength = snprintf((char *)uartTxBuffer, UART_TX_BUFFER_SIZE, "La valeur Speed doit être un entier entre 0 et 100 !\r\n");
		HAL_UART_Transmit(&huart2, uartTxBuffer, uartTxStringLength, HAL_MAX_DELAY);
	}
}

/**
 * @brief Initialise le DMA et l'ADC.
 *
 * @param none
 * @retval none
 */

void executeCurrentValue(void) {
    // Initialisation des buffers pour les données brutes et réelles
    uint32_t adcBuffer[ADC_DMA_Buffer_Size]; // Tampon des valeurs brutes
    uint32_t adcBuffer_reel[ADC_DMA_Buffer_Size]; // Tampon pour les valeurs réelles (courant)

    // Démarre la calibration de l'ADC
    HAL_ADCEx_Calibration_Start(&hadc1, ADC_SINGLE_ENDED);

    // Démarre la conversion ADC en mode DMA (avec le trigger Timer 1)
    HAL_ADC_Start_DMA(&hadc1, (uint32_t*)adcBuffer, ADC_DMA_Buffer_Size);  // Conversion ADC en mode DMA
    HAL_TIM_Base_Start(&htim1);

    for (int i = 0; i < ADC_DMA_Buffer_Size; i++) {
        // 1. Lire la valeur brute de l'ADC à partir du tampon
        uint32_t adcValue_Brut = adcBuffer[i];

        // 2. Convertir la valeur brute en tension (calcul)
        int Vadc = (adcValue_Brut * ADC_Vref) / (1 << ADC_Bits);  // Formule de conversion en tension

        // 3. Calculer la valeur réelle du courant (en Amperes)
        int I_reel = (Vadc - Voffset) / Sn;  // Calcul du courant réel (en A)

        // 4. Stocker la valeur réelle dans le tampon adcBuffer_reel
        adcBuffer_reel[i] = I_reel;  // Stockage du courant réel dans le tampon

        // 5. Affichage des valeurs brutes et réelles via UART
        int uartTxStringLength;

//        // Affichage de la valeur brute de l'ADC
//        uartTxStringLength = snprintf((char *)uartTxBuffer, UART_TX_BUFFER_SIZE, "I_Brut[%d] = %lu\r\n", i, adcValue_Brut);
//        HAL_UART_Transmit(&huart2, uartTxBuffer, uartTxStringLength, HAL_MAX_DELAY);

        // Affichage de la valeur réelle du courant
        uartTxStringLength = snprintf((char *)uartTxBuffer, UART_TX_BUFFER_SIZE, "I_ampere[%d] = %d mA\r\n", i, I_reel);
        HAL_UART_Transmit(&huart2, uartTxBuffer, uartTxStringLength, HAL_MAX_DELAY);
    }

    // Vous pouvez arrêter la conversion ou laisser le DMA en mode continu, selon votre cas
    HAL_ADC_Stop_DMA(&hadc1); // Arrêt du DMA après la collecte des données
}

/**
 * @brief Déclaration de la fonction executeInfoSpeed
 *
 * @param none
 * @retval none
 */

void executeInfoSpeed(void) {
    // Variables locales
    uint32_t capture_A = 0;  // Capture du signal A
    uint32_t capture_B = 0;  // Capture du signal B
    uint32_t capture_Z = 0;  // Capture du signal Z
    uint32_t previous_Z_capture = 0;  // Capture précédente du signal Z
    int direction = 0;       // Direction du moteur (1 = horaire, -1 = antihoraire)
    float rotation_speed = 0.0f;  // Vitesse de rotation (en RPM)

    // 1. Récupération des valeurs des captures des signaux A, B et Z
    capture_A = HAL_TIM_ReadCapturedValue(&htim3, TIM_CHANNEL_1);  // Lire la valeur du signal A
    capture_B = HAL_TIM_ReadCapturedValue(&htim3, TIM_CHANNEL_2);  // Lire la valeur du signal B
    capture_Z = HAL_TIM_ReadCapturedValue(&htim3, TIM_CHANNEL_3);  // Lire la valeur du signal Z

    // 2. Calcul de la vitesse de rotation en RPM basé sur le signal Z
    if (previous_Z_capture != 0) {
        uint32_t time_difference = capture_Z - previous_Z_capture;
        if (time_difference > 0) {
            // La fréquence de rotation est l'inverse du temps écoulé entre deux impulsions Z
            // Conversion en RPM (1 tour par seconde = 60 tours par minute)
            rotation_speed = 60000000.0f / (float)time_difference;  // Multiplier par 60 et 1000 pour obtenir RPM
        }
    }

    // Mettre à jour la capture précédente du signal Z pour la prochaine itération
    previous_Z_capture = capture_Z;

    // 3. Calcul du sens de rotation basé sur les captures des signaux A et B
    if (capture_A > capture_B) {
        direction = 1;  // Sens horaire (A en avance sur B)
    } else if (capture_A < capture_B) {
        direction = -1; // Sens antihoraire (B en avance sur A)
    } else {
        direction = 0;  // Pas de mouvement détecté (A et B sont synchronisés)
    }

    // 4. Affichage des résultats : Vitesse et Direction via UART
    int uartTxStringLength;
    uint8_t uartTxBuffer[UART_TX_BUFFER_SIZE];  // Buffer pour l'envoi de données UART

    if (direction == 1) {
        uartTxStringLength = snprintf((char *)uartTxBuffer, UART_TX_BUFFER_SIZE,
            "Vitesse: %.2f RPM, Direction: Horaire\r\n", rotation_speed);
    } else if (direction == -1) {
        uartTxStringLength = snprintf((char *)uartTxBuffer, UART_TX_BUFFER_SIZE,
            "Vitesse: %.2f RPM, Direction: Antihoraire\r\n", rotation_speed);
    } else {
        uartTxStringLength = snprintf((char *)uartTxBuffer, UART_TX_BUFFER_SIZE,
            "Vitesse: %.2f RPM, Direction: Inconnue\r\n", rotation_speed);
    }

    // Transmettre les données via UART
    HAL_UART_Transmit(&huart2, uartTxBuffer, uartTxStringLength, HAL_MAX_DELAY);
}



