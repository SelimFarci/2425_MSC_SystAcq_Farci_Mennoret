/**
 * @file doc.c
 * @brief Documentation globale du projet.
 *
 * Ce fichier contient des descriptions générales du projet STM32, son architecture
 * et les modules utilisés.
 */

/**
 * @mainpage Documentation du Projet STM32
 *
 * @section intro_section Introduction
 * Ce projet est une application embarquée pour STM32 qui implémente [fonctionnalité principale].
 *
 * @section arch_section Architecture
 * Le projet est structuré comme suit :
 * - **Drivers** : Contient les pilotes bas-niveau.
 * - **Middleware** : [Description]
 * - **Application** : Code utilisateur.
 *
 * @section build_section Instructions de Compilation
 * Utilisez les commandes suivantes pour compiler :
 * - `make`
 * - Ou l'environnement STM32CubeIDE.
 *
 * @section contact_section Contact
 * Développeur : [Ton Nom]
 * Email : [Ton Email]
 */
