/*
 * shell.h
 *
 *  Created on: Oct 10, 2024
 *      Author: PC
 */

#ifndef INC_SHELL_H_
#define INC_SHELL_H_

#define UART_TX_BUFFER_SIZE 64
#define UART_RX_BUFFER_SIZE 1
#define CMD_BUFFER_SIZE 64
#define MAX_ARGS 9
// LF = line feed, saut de ligne
#define ASCII_LF 0x0A
// CR = carriage return, retour chariot
#define ASCII_CR 0x0D
// DEL = delete
#define ASCII_DEL 0x7F

void Shell_Init(void);
void Shell_Loop(void);

#endif /* INC_SHELL_H_ */
